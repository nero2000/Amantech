package com.cloudappstudio.utility;

public class CloudConstants {
	public static final String CAS360_APPS_JSON = "https://cloudappstudio360.appspot.com/api/json/v2/apps.json";  
	public static final String CAS360_VIEWS_JSON = "https://cloudappstudio360.appspot.com/api/json/v2/views.json";
	public static final String CAS360_VIEWDATA_JSON = "https://cloudappstudio360.appspot.com/api/json/v2/viewdata";
}
