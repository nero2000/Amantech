CloudAppStudio for Android
=========================

This project depends on the library ActionBarSherlock.
Make sure that the library is added to the project or it won't work.
